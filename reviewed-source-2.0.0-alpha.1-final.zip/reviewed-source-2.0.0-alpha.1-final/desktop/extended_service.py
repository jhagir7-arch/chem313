from hypothesislab.extended_worker import main

if __name__ == "__main__":
    main()
